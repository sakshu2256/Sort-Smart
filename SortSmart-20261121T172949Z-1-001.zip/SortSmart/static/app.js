// ─── SortSmart app.js ────────────────────────────────────────────────────────
// Features:
//  • Photo mode (LLaVA/Ollama) + Description mode (Groq)
//  • Voice input (SpeechRecognition) in all 3 languages
//  • Auto-read results aloud (SpeechSynthesis) — optional toggle
//  • Location: GPS or city/area search
//  • Interactive Leaflet map of nearby recycling points
// ─────────────────────────────────────────────────────────────────────────────

const form            = document.getElementById("analyze-form");
const imageInput      = document.getElementById("image");
const descriptionInput= document.getElementById("description");
const submitButton    = document.getElementById("submit-button");
const voiceButton     = document.getElementById("voice-input");
const statusMessage   = document.getElementById("status");
const resultSection   = document.getElementById("result");
const dropoffStatus   = document.getElementById("dropoff-status");
const dropoffResults  = document.getElementById("dropoff-results");
const confirmButton   = document.getElementById("confirm-sort");
const speakButton     = document.getElementById("speak-result");
const stopReadingButton=document.getElementById("stop-reading");
const speechStatus    = document.getElementById("speech-status");
const autoSpeakToggle = document.getElementById("auto-speak-toggle");
const locationDisplay = document.getElementById("location-display");
const locationLabel   = document.getElementById("location-label");
const changeLocationBtn=document.getElementById("change-location");
const locationControls= document.getElementById("location-controls");

let currentResult   = null;
let currentLanguage = "English";
let activeUtterance = null;
let map             = null;
let mapMarkers      = null;
let leafletPromise  = null;
let savedLocation   = null; // { latitude, longitude, label }

// ─── Speech locales & text maps ──────────────────────────────────────────────
const speechLocales = { English: "en-IN", Hindi: "hi-IN", Punjabi: "pa-IN" };
const spokenStreams = {
  English: { wet: "wet waste", dry: "dry waste", sanitary: "sanitary waste", special_care: "special-care waste" },
  Hindi:   { wet: "गीला कचरा", dry: "सूखा कचरा", sanitary: "स्वच्छता का कचरा", special_care: "विशेष देखभाल वाला कचरा" },
  Punjabi: { wet: "ਗਿੱਲਾ ਕੂੜਾ", dry: "ਸੁੱਕਾ ਕੂੜਾ", sanitary: "ਸੈਨੇਟਰੀ ਕੂੜਾ", special_care: "ਖ਼ਾਸ ਸੰਭਾਲ ਵਾਲਾ ਕੂੜਾ" },
};
const speechLabels = {
  English: { main: "Main stream", condition: "Visible condition", prep: "Preparation", part: "Sort this part as" },
  Hindi:   { main: "मुख्य कचरा वर्ग", condition: "दिखाई देने वाली स्थिति", prep: "तैयारी", part: "इस हिस्से को इसमें डालें" },
  Punjabi: { main: "ਮੁੱਖ ਕੂੜਾ ਕਿਸਮ", condition: "ਦਿਖਾਈ ਦੇਣ ਵਾਲੀ ਹਾਲਤ", prep: "ਤਿਆਰੀ", part: "ਇਸ ਹਿੱਸੇ ਨੂੰ ਇਸ ਤਰ੍ਹਾਂ ਛਾਂਟੋ" },
};

// ─── Speech synthesis ─────────────────────────────────────────────────────────
function stopSpeech(announce = false) {
  activeUtterance = null;
  if ("speechSynthesis" in window) window.speechSynthesis.cancel();
  speakButton.disabled = !("speechSynthesis" in window);
  stopReadingButton.hidden = true;
  speechStatus.textContent = announce ? "Speech stopped." : "";
}

function buildSpeechText(result) {
  const labels  = speechLabels[currentLanguage];
  const streams = spokenStreams[currentLanguage];
  const segments = [
    result.item,
    `${labels.main}: ${streams[result.stream]}`,
    result.contamination && `${labels.condition}: ${result.contamination}`,
    result.prep_steps.length && `${labels.prep}: ${result.prep_steps.join(". ")}`,
    ...result.parts.map(part =>
      [`${part.item}, ${part.material}. ${labels.part}: ${streams[part.stream]}.`, part.prep_steps.join(". ")]
        .filter(Boolean).join(" ")
    ),
    result.reason,
  ];
  return segments.filter(Boolean).join(". ");
}

function speakResult(result) {
  if (!("speechSynthesis" in window) || !("SpeechSynthesisUtterance" in window)) return;
  stopSpeech();
  const utterance = new SpeechSynthesisUtterance(buildSpeechText(result));
  utterance.lang  = speechLocales[currentLanguage];
  utterance.rate  = 0.95;
  activeUtterance = utterance;
  speakButton.disabled   = true;
  stopReadingButton.hidden = false;
  speechStatus.textContent = "Starting voice playback…";
  utterance.onstart = () => { if (activeUtterance === utterance) speechStatus.textContent = "Reading the sorting plan aloud."; };
  utterance.onend   = () => { if (activeUtterance === utterance) stopSpeech(); };
  utterance.onerror = () => {
    if (activeUtterance === utterance) {
      stopSpeech();
      speechStatus.textContent = "Speech playback failed. Check that your device has a voice for this language.";
    }
  };
  try { window.speechSynthesis.speak(utterance); }
  catch (error) { stopSpeech(); speechStatus.textContent = error.message || "Could not start speech playback."; }
}

if ("speechSynthesis" in window && "SpeechSynthesisUtterance" in window) {
  speakButton.addEventListener("click", () => { if (currentResult) speakResult(currentResult); });
  stopReadingButton.addEventListener("click", () => stopSpeech(true));
} else {
  speakButton.disabled = true;
  document.getElementById("speech-hint").textContent = "Speech playback is not supported by this browser.";
}

// ─── Voice input (SpeechRecognition) ──────────────────────────────────────────
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;

if (SpeechRecognition) {
  voiceButton.disabled = false;
  document.getElementById("voice-hint").textContent =
    "Tap the microphone button to speak your item description.";

  voiceButton.addEventListener("click", () => {
    if (recognition) { recognition.stop(); recognition = null; voiceButton.textContent = "🎙️ Speak instead"; return; }
    recognition = new SpeechRecognition();
    recognition.lang = speechLocales[currentLanguage];
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    voiceButton.textContent = "⏹ Stop listening";
    statusMessage.textContent = "Listening… speak your item description.";
    recognition.onresult = event => {
      descriptionInput.value = event.results[0][0].transcript;
      statusMessage.textContent = "";
    };
    recognition.onerror  = () => { statusMessage.textContent = "Voice input failed — please type instead."; };
    recognition.onend    = () => { recognition = null; voiceButton.textContent = "🎙️ Speak instead"; };
    recognition.start();
  });
} else {
  document.getElementById("voice-hint").textContent = "Voice input is not supported in this browser.";
}

// ─── Mode switching ───────────────────────────────────────────────────────────
const photoPanel       = document.getElementById("photo-panel");
const descriptionPanel = document.getElementById("description-panel");

function setMode(mode) {
  const isPhoto = mode === "photo";
  photoPanel.hidden       =  !isPhoto;
  descriptionPanel.hidden =   isPhoto;
  imageInput.disabled     =  !isPhoto;
  descriptionInput.disabled = isPhoto;
  if (recognition) { recognition.stop(); recognition = null; }
  if (!isPhoto) stopSpeech();
}

document.querySelectorAll("input[name='mode']").forEach(radio => {
  radio.addEventListener("change", e => setMode(e.target.value));
});

document.getElementById("language").addEventListener("change", e => {
  currentLanguage = e.target.value;
  if (recognition) { recognition.lang = speechLocales[currentLanguage]; }
});

// ─── Analyze form ─────────────────────────────────────────────────────────────
form.addEventListener("submit", async event => {
  event.preventDefault();
  stopSpeech();
  resultSection.hidden = true;
  statusMessage.textContent = "";

  const mode        = document.querySelector("input[name='mode']:checked")?.value;
  const language    = document.getElementById("language").value;
  currentLanguage   = language;
  const formData    = new FormData();
  formData.append("language", language);

  if (mode === "photo") {
    const file = imageInput.files[0];
    if (!file) { statusMessage.textContent = "Please choose a photo first."; return; }
    formData.append("image", file);
    statusMessage.textContent = "Analysing your photo…";
  } else {
    const desc = descriptionInput.value.trim();
    if (!desc) { statusMessage.textContent = "Please describe the item or use voice input."; return; }
    formData.append("description", desc);
    statusMessage.textContent = "Analysing your description…";
  }

  submitButton.disabled = true;
  confirmButton.disabled = true;

  try {
    const response = await fetch("/api/analyze", { method: "POST", body: formData });
    const data     = await response.json();
    if (!response.ok) { statusMessage.textContent = data.error || `Error ${response.status}`; return; }
    renderResult(data);
    // Auto-speak if toggle is on
    if (autoSpeakToggle.checked) {
      setTimeout(() => speakResult(data), 600);
    }
  } catch (error) {
    statusMessage.textContent = error.message || "Network error — is the server running?";
  } finally {
    submitButton.disabled = false;
    statusMessage.textContent = "";
  }
});

// ─── Render result ────────────────────────────────────────────────────────────
const STREAM_LABELS = { wet: "Wet", dry: "Dry", sanitary: "Sanitary", special_care: "Special Care" };

function renderResult(data) {
  currentResult = data;
  resultSection.hidden = false;
  resultSection.scrollIntoView({ behavior: "smooth", block: "start" });

  document.getElementById("stream").textContent       = STREAM_LABELS[data.stream] ?? data.stream;
  document.getElementById("item").textContent         = data.item ?? "";
  document.getElementById("material").textContent     = data.material ?? "";
  document.getElementById("contamination").textContent= data.contamination ?? "";
  document.getElementById("confidence").textContent   = data.confidence != null ? `${data.confidence}%` : "";

  // Parts
  const partsSection = document.getElementById("parts-section");
  const partsContainer = document.getElementById("parts");
  partsContainer.replaceChildren();
  if (data.parts?.length) {
    partsSection.hidden = false;
    for (const part of data.parts) {
      const card = document.createElement("div");
      card.className = "part-card";
      card.innerHTML = `
        <div class="part-heading">
          <span>${part.item ?? ""}</span>
          <span class="part-stream">${STREAM_LABELS[part.stream] ?? part.stream ?? ""}</span>
        </div>
        <p class="part-material">${part.material ?? ""}</p>
        ${part.prep_steps?.length ? `<ul>${part.prep_steps.map(s => `<li>${s}</li>`).join("")}</ul>` : ""}
      `;
      partsContainer.append(card);
    }
  } else {
    partsSection.hidden = true;
  }

  // Prep steps
  const prepList = document.getElementById("prep-steps");
  prepList.replaceChildren();
  for (const step of data.prep_steps ?? []) {
    const li = document.createElement("li");
    li.textContent = step;
    prepList.append(li);
  }

  document.getElementById("reason").textContent = data.reason ?? "";
  confirmButton.disabled = false;

  // Reset speech UI
  speakButton.disabled = !("speechSynthesis" in window);
  stopReadingButton.hidden = true;
  speechStatus.textContent = "";
}

// ─── Confirm / tally ──────────────────────────────────────────────────────────
function loadTally() {
  try { return JSON.parse(localStorage.getItem("sortsmart_tally") || "{}"); }
  catch { return {}; }
}

function renderTally(tally) {
  const counts = { wet: 0, dry: 0, sanitary: 0, special_care: 0 };
  for (const [stream, count] of Object.entries(tally)) {
    if (stream in counts) counts[stream] = count;
  }
  const total = Object.values(counts).reduce((a, b) => a + b, 0);
  document.getElementById("tally-total").textContent         = total;
  document.getElementById("tally-wet").textContent           = counts.wet;
  document.getElementById("tally-dry").textContent           = counts.dry;
  document.getElementById("tally-sanitary").textContent      = counts.sanitary;
  document.getElementById("tally-special-care").textContent  = counts.special_care;
}

renderTally(loadTally());

confirmButton.addEventListener("click", () => {
  if (!currentResult?.stream) return;
  try {
    const tally = loadTally();
    tally[currentResult.stream] = (tally[currentResult.stream] || 0) + 1;
    localStorage.setItem("sortsmart_tally", JSON.stringify(tally));
    renderTally(tally);
    confirmButton.disabled = true;
    document.getElementById("tally-status").textContent = "✓ Saved! This confirmation is kept only in this browser.";
  } catch (error) {
    document.getElementById("tally-status").textContent = `Could not save your tally: ${error.message}`;
  }
});

// ─── Leaflet map loader ───────────────────────────────────────────────────────
function loadLeaflet() {
  if (window.L) return Promise.resolve(window.L);
  if (!leafletPromise) {
    leafletPromise = new Promise((resolve, reject) => {
      const css    = document.createElement("link");
      css.rel      = "stylesheet";
      css.href     = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
      document.head.append(css);

      const script = document.createElement("script");
      script.src   = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
      script.onload  = () => resolve(window.L);
      script.onerror = () => reject(new Error("Could not load the map library."));
      document.head.append(script);
    });
  }
  return leafletPromise;
}

// ─── Reverse geocode label ────────────────────────────────────────────────────
async function reverseGeocode(lat, lon) {
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=jsonv2`;
    const res = await fetch(url, { headers: { "User-Agent": "SortSmart/1.0" } });
    const data = await res.json();
    return data.display_name?.split(",").slice(0, 3).join(", ") || `${lat.toFixed(4)}, ${lon.toFixed(4)}`;
  } catch {
    return `${lat.toFixed(4)}, ${lon.toFixed(4)}`;
  }
}

// ─── Show saved location ──────────────────────────────────────────────────────
function showLocationDisplay(label) {
  locationLabel.textContent = label;
  locationDisplay.hidden    = false;
  locationControls.hidden   = true;
}

changeLocationBtn.addEventListener("click", () => {
  locationDisplay.hidden  = true;
  locationControls.hidden = false;
  savedLocation = null;
  dropoffResults.hidden = true;
  dropoffStatus.textContent = "";
});

// ─── Load nearby recycling points ─────────────────────────────────────────────
async function loadNearby(latitude, longitude, locationName) {
  dropoffStatus.textContent = "🔍 Looking for recycling points within 5 km…";
  savedLocation = { latitude, longitude, label: locationName };

  const response = await fetch(`/api/dropoffs?lat=${latitude}&lon=${longitude}`);
  const data     = await response.json();
  if (!response.ok) throw new Error(data.error || `Nearby search failed (${response.status}).`);

  const L = await loadLeaflet();
  dropoffResults.hidden = false;

  if (!map) {
    map = L.map("dropoff-map").setView([latitude, longitude], 14);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    }).addTo(map);
    mapMarkers = L.layerGroup().addTo(map);
  }

  map.setView([latitude, longitude], 14);
  mapMarkers.clearLayers();

  // User location marker
  const userIcon = L.divIcon({ className: "", html: "📍", iconSize: [28, 28], iconAnchor: [14, 28] });
  L.marker([latitude, longitude], { icon: userIcon }).addTo(mapMarkers)
   .bindPopup(`<b>Your location</b><br>${locationName}`).openPopup();

  const list = document.getElementById("dropoff-list");
  list.replaceChildren();

  // Handle fallback (Overpass API unavailable) — show map + Google Maps link
  if (data.fallback) {
    const li = document.createElement("li");
    li.innerHTML = `OpenStreetMap data is temporarily unavailable. ` +
      `<a href="${data.gmaps_url || `https://www.google.com/maps/search/recycling/@${latitude},${longitude},14z`}" target="_blank" rel="noreferrer">🔍 Search on Google Maps</a> for nearby recycling centres.`;
    list.append(li);
    setTimeout(() => map.invalidateSize(), 300);
    showLocationDisplay(locationName);
    dropoffStatus.textContent = "⚠️ " + (data.message || "OpenStreetMap data unavailable — Google Maps link shown above.");
    return;
  }

  if (!data.places?.length) {
    const empty = document.createElement("li");
    const gmUrl = `https://www.google.com/maps/search/recycling/@${latitude},${longitude},14z`;
    empty.innerHTML = `No recycling points mapped within 5 km. <a href="${gmUrl}" target="_blank" rel="noreferrer">🔍 Try Google Maps</a> instead.`;
    list.append(empty);
  }

  for (const place of data.places ?? []) {
    // Recycling marker
    const icon = L.divIcon({ className: "", html: "♻️", iconSize: [24, 24], iconAnchor: [12, 24] });
    const marker = L.marker([place.latitude, place.longitude], { icon }).addTo(mapMarkers);
    marker.bindPopup(`<b>${place.name}</b><br>${place.distance_km} km away${place.details ? `<br>${place.details}` : ""}`);

    const item     = document.createElement("li");
    const link     = document.createElement("a");
    link.href      = place.osm_url;
    link.target    = "_blank";
    link.rel       = "noreferrer";
    link.textContent = place.name;
    link.addEventListener("click", () => marker.openPopup());

    const dist = document.createElement("span");
    dist.className = "dropoff-distance";
    dist.textContent = `${place.distance_km} km away${place.details ? ` · ${place.details}` : ""}`;
    item.append(link, dist);
    list.append(item);
  }

  setTimeout(() => map.invalidateSize(), 300);
  showLocationDisplay(locationName);

  dropoffStatus.textContent = data.places?.length
    ? `✅ Found ${data.places.length} recycling point${data.places.length === 1 ? "" : "s"} within 5 km.`
    : "⚠️ No mapped points found within 5 km.";
}

// ─── GPS location button ───────────────────────────────────────────────────────
document.getElementById("find-dropoffs").addEventListener("click", () => {
  dropoffStatus.textContent = "";
  if (!navigator.geolocation) {
    dropoffStatus.textContent = "GPS is not available in this browser. Try searching by city.";
    return;
  }
  dropoffStatus.textContent = "📡 Requesting your GPS location…";
  navigator.geolocation.getCurrentPosition(
    async ({ coords }) => {
      const label = await reverseGeocode(coords.latitude, coords.longitude);
      loadNearby(coords.latitude, coords.longitude, label).catch(err => {
        dropoffStatus.textContent = err.message || "Could not load nearby places.";
      });
    },
    () => {
      dropoffStatus.textContent = "Location permission denied. Please search by city or area below.";
    },
    { enableHighAccuracy: false, maximumAge: 60_000, timeout: 12_000 }
  );
});

// ─── City/area search ─────────────────────────────────────────────────────────
async function doAreaSearch() {
  const query = document.getElementById("location-query").value.trim();
  if (!query) { dropoffStatus.textContent = "Enter a city, area, or pin code."; return; }
  dropoffStatus.textContent = `🔍 Finding "${query}"…`;
  try {
    const response = await fetch(`/api/geocode?q=${encodeURIComponent(query)}`);
    const data     = await response.json();
    if (!response.ok) throw new Error(data.error || `Area search failed (${response.status}).`);
    await loadNearby(data.latitude, data.longitude, query);
  } catch (error) {
    dropoffStatus.textContent = error.message || "Could not search that area.";
  }
}

document.getElementById("search-area").addEventListener("click", doAreaSearch);

document.getElementById("location-query").addEventListener("keydown", e => {
  if (e.key === "Enter") { e.preventDefault(); doAreaSearch(); }
});

// ─── Service worker ───────────────────────────────────────────────────────────
if ("serviceWorker" in navigator && window.isSecureContext) {
  navigator.serviceWorker.register("/service-worker.js").catch(() => {
    statusMessage.textContent = "SortSmart is available online, but its offline app shell could not be enabled.";
  });
}

// ─── Boot ─────────────────────────────────────────────────────────────────────
setMode("photo");
renderTally(loadTally());
