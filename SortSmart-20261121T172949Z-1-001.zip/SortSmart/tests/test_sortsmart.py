import unittest
import json
from types import SimpleNamespace
from unittest.mock import patch

from sortsmart import (
    DEFAULT_MODEL,
    _request_sorting,
    analyze,
    analyze_description,
    speak_result,
    speech_text,
    validate_result,
)


def example_result():
    return {
        "item": "Greasy takeaway box",
        "material": "Cardboard and plastic",
        "stream": "wet",
        "prep_steps": ["Separate the clean lid"],
        "reason": "The soiled section may not be recyclable locally.",
        "confidence": 0.8,
        "contamination": "Grease is visible on the cardboard.",
        "parts": [
            {
                "item": "Greasy cardboard box",
                "material": "Cardboard",
                "stream": "wet",
                "prep_steps": ["Keep heavily soiled sections separate."],
            },
            {
                "item": "Clean lid",
                "material": "Plastic",
                "stream": "dry",
                "prep_steps": ["Empty and rinse if accepted locally."],
            },
        ],
    }


class ValidateResultTests(unittest.TestCase):
    def test_accepts_component_level_sorting(self):
        result = example_result()
        self.assertIs(validate_result(result), result)

    def test_rejects_unknown_component_stream(self):
        result = example_result()
        result["parts"][1]["stream"] = "recycling"
        with self.assertRaisesRegex(ValueError, "stream"):
            validate_result(result)

    def test_rejects_missing_component_breakdown(self):
        result = example_result()
        result["parts"] = []
        with self.assertRaisesRegex(ValueError, "parts"):
            validate_result(result)

    def test_text_analysis_rejects_overlong_descriptions_before_api_call(self):
        with self.assertRaisesRegex(ValueError, "300 characters"):
            analyze_description("x" * 301)

    @patch("groq.Groq")
    def test_request_uses_groq_json_mode_and_validates_result(self, client_class):
        response = SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content=json.dumps(example_result())))]
        )
        client = client_class.return_value
        client.chat.completions.create.return_value = response
        user_content = "Analyze a plastic bottle."

        with patch.dict("os.environ", {"GROQ_API_KEY": "test-key"}, clear=True):
            result = _request_sorting(user_content, model=None)

        self.assertEqual(result, example_result())
        client_class.assert_called_once_with(api_key="test-key")
        kwargs = client.chat.completions.create.call_args.kwargs
        self.assertEqual(kwargs["model"], DEFAULT_MODEL)
        self.assertEqual(kwargs["messages"][1]["content"], user_content)
        self.assertEqual(kwargs["response_format"], {"type": "json_object"})
        self.assertIn("households in India", kwargs["messages"][0]["content"])

    def test_request_requires_groq_key(self):
        with patch.dict("os.environ", {}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "GROQ_API_KEY"):
                _request_sorting("bottle", model=None)

    @patch("groq.Groq")
    def test_image_analysis_uses_groq_inline_image(self, client_class):
        response = SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content=json.dumps(example_result())))]
        )
        client_class.return_value.chat.completions.create.return_value = response
        image_bytes = b"example-image"

        with patch.dict("os.environ", {"GROQ_API_KEY": "test-key"}, clear=True):
            result = analyze(image_bytes, "image/jpeg")

        self.assertEqual(result, example_result())
        messages = client_class.return_value.chat.completions.create.call_args.kwargs["messages"]
        content = messages[1]["content"]
        self.assertEqual(content[0]["type"], "image_url")
        self.assertTrue(content[0]["image_url"]["url"].startswith("data:image/jpeg;base64,"))

    def test_speech_summary_localizes_stream_name(self):
        text = speech_text(example_result(), "Hindi")
        self.assertIn("मुख्य कचरा वर्ग: गीला कचरा", text)

    def test_cli_speech_rejects_non_macos_platforms(self):
        with patch("sortsmart.sys.platform", "linux"):
            with self.assertRaisesRegex(RuntimeError, "macOS only"):
                speak_result(example_result(), "English")

    @patch("sortsmart.subprocess.run")
    @patch("sortsmart._macos_voice", return_value="Aarav")
    def test_cli_speech_uses_selected_system_voice(self, _voice, run):
        with patch("sortsmart.sys.platform", "darwin"):
            speak_result(example_result(), "Hindi")
        self.assertEqual(run.call_args.args[0][:3], ["say", "-v", "Aarav"])
        self.assertIn("गीला कचरा", run.call_args.args[0][3])


if __name__ == "__main__":
    unittest.main()
