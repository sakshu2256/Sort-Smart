"""Tests for sortsmart_claude.py — Anthropic-primary, Groq-fallback integration."""

import json
import sys
import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(__import__("pathlib").Path(__file__).parent.parent))

from sortsmart_claude import (
    DEFAULT_ANTHROPIC_MODEL,
    DEFAULT_GROQ_MODEL,
    _active_provider,
    _request_sorting_anthropic,
    _request_sorting_groq,
    active_provider_name,
    analyze,
    analyze_description,
    validate_result,
)


def example_result():
    return {
        "item": "Greasy takeaway box",
        "material": "Cardboard and plastic",
        "stream": "wet",
        "prep_steps": ["Separate the clean lid"],
        "reason": "The soiled section may not be recyclable locally.",
        "confidence": 0.8,
        "contamination": "Grease is visible on the cardboard.",
        "parts": [
            {"item": "Greasy cardboard box", "material": "Cardboard", "stream": "wet",
             "prep_steps": ["Keep heavily soiled sections separate."]},
            {"item": "Clean lid", "material": "Plastic", "stream": "dry",
             "prep_steps": ["Empty and rinse if accepted locally."]},
        ],
    }


# ---------------------------------------------------------------------------
# Provider detection
# ---------------------------------------------------------------------------

class ProviderDetectionTests(unittest.TestCase):
    def test_explicit_anthropic_env(self):
        with patch.dict("os.environ", {"SORTSMART_PROVIDER": "anthropic", "ANTHROPIC_API_KEY": "k"}, clear=True):
            self.assertEqual(_active_provider(), "anthropic")

    def test_explicit_groq_env(self):
        with patch.dict("os.environ", {"SORTSMART_PROVIDER": "groq", "GROQ_API_KEY": "k"}, clear=True):
            self.assertEqual(_active_provider(), "groq")

    def test_auto_prefers_anthropic_when_key_set(self):
        with patch.dict("os.environ", {"ANTHROPIC_API_KEY": "k", "GROQ_API_KEY": "g"}, clear=True):
            self.assertEqual(_active_provider(), "anthropic")

    def test_auto_uses_groq_when_only_groq_key_set(self):
        with patch.dict("os.environ", {"GROQ_API_KEY": "g"}, clear=True):
            self.assertEqual(_active_provider(), "groq")

    def test_raises_when_no_key(self):
        with patch.dict("os.environ", {}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "ANTHROPIC_API_KEY"):
                _active_provider()

    def test_active_provider_name_includes_model(self):
        with patch.dict("os.environ", {"ANTHROPIC_API_KEY": "k"}, clear=True):
            name = active_provider_name()
            self.assertIn("Anthropic", name)
            self.assertIn(DEFAULT_ANTHROPIC_MODEL, name)


# ---------------------------------------------------------------------------
# Validation (shared with sortsmart.py — just sanity-check the module copy)
# ---------------------------------------------------------------------------

class ValidateResultTests(unittest.TestCase):
    def test_accepts_valid_result(self):
        r = example_result()
        self.assertIs(validate_result(r), r)

    def test_rejects_unknown_stream(self):
        r = example_result()
        r["stream"] = "recycling"
        with self.assertRaisesRegex(ValueError, "stream"):
            validate_result(r)

    def test_rejects_empty_parts(self):
        r = example_result()
        r["parts"] = []
        with self.assertRaisesRegex(ValueError, "parts"):
            validate_result(r)


# ---------------------------------------------------------------------------
# Anthropic backend
# ---------------------------------------------------------------------------

class AnthropicBackendTests(unittest.TestCase):
    def _mock_client(self, text):
        """Return a mock Anthropic client that replies with *text*."""
        content_block = SimpleNamespace(text=text)
        message = SimpleNamespace(content=[content_block])
        client = MagicMock()
        client.messages.create.return_value = message
        return client

    def test_calls_anthropic_api_with_system_prompt(self):
        client = self._mock_client(json.dumps(example_result()))
        with patch("anthropic.Anthropic", return_value=client):
            with patch.dict("os.environ", {"ANTHROPIC_API_KEY": "test-key"}, clear=True):
                result = _request_sorting_anthropic(
                    [{"type": "text", "text": "Analyze a bottle."}],
                    model=None,
                )
        self.assertEqual(result, example_result())
        kwargs = client.messages.create.call_args.kwargs
        self.assertEqual(kwargs["model"], DEFAULT_ANTHROPIC_MODEL)
        self.assertIn("SortSmart", kwargs["system"])

    def test_strips_markdown_code_fence(self):
        raw = "```json\n" + json.dumps(example_result()) + "\n```"
        client = self._mock_client(raw)
        with patch("anthropic.Anthropic", return_value=client):
            with patch.dict("os.environ", {"ANTHROPIC_API_KEY": "test-key"}, clear=True):
                result = _request_sorting_anthropic(
                    [{"type": "text", "text": "Analyze a bottle."}],
                    model=None,
                )
        self.assertEqual(result["item"], example_result()["item"])

    def test_raises_on_missing_key(self):
        with patch.dict("os.environ", {}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "ANTHROPIC_API_KEY"):
                _request_sorting_anthropic([{"type": "text", "text": "x"}], model=None)

    def test_raises_on_invalid_json(self):
        client = self._mock_client("not valid json")
        with patch("anthropic.Anthropic", return_value=client):
            with patch.dict("os.environ", {"ANTHROPIC_API_KEY": "k"}, clear=True):
                with self.assertRaisesRegex(ValueError, "invalid JSON"):
                    _request_sorting_anthropic([{"type": "text", "text": "x"}], model=None)


# ---------------------------------------------------------------------------
# Fallback behaviour
# ---------------------------------------------------------------------------

class FallbackTests(unittest.TestCase):
    def test_analyze_description_falls_back_to_groq_when_anthropic_fails(self):
        """If Anthropic raises, Groq should be tried when GROQ_API_KEY is set."""
        with patch("sortsmart_claude._active_provider", return_value="anthropic"):
            with patch("sortsmart_claude._request_sorting_anthropic", side_effect=RuntimeError("Anthropic down")):
                with patch("sortsmart_claude._request_sorting_groq", return_value=example_result()) as groq_mock:
                    with patch.dict("os.environ", {"GROQ_API_KEY": "g"}, clear=True):
                        result = analyze_description("plastic bottle")
        groq_mock.assert_called_once()
        self.assertEqual(result["item"], example_result()["item"])

    def test_analyze_description_reraises_when_no_groq_fallback(self):
        with patch("sortsmart_claude._active_provider", return_value="anthropic"):
            with patch("sortsmart_claude._request_sorting_anthropic", side_effect=RuntimeError("Anthropic down")):
                with patch.dict("os.environ", {}, clear=True):
                    with self.assertRaises(RuntimeError):
                        analyze_description("bottle")


# ---------------------------------------------------------------------------
# Image analysis
# ---------------------------------------------------------------------------

class ImageAnalysisTests(unittest.TestCase):
    def test_analyze_builds_base64_image_block(self):
        content_block = SimpleNamespace(text=json.dumps(example_result()))
        message = SimpleNamespace(content=[content_block])
        client = MagicMock()
        client.messages.create.return_value = message

        with patch("anthropic.Anthropic", return_value=client):
            with patch("sortsmart_claude._active_provider", return_value="anthropic"):
                with patch.dict("os.environ", {"ANTHROPIC_API_KEY": "k"}, clear=True):
                    result = analyze(b"fake-image-bytes", "image/jpeg", lang="Hindi")

        self.assertEqual(result["item"], example_result()["item"])
        call_content = client.messages.create.call_args.kwargs["messages"][0]["content"]
        image_block = call_content[0]
        self.assertEqual(image_block["type"], "image")
        self.assertEqual(image_block["source"]["media_type"], "image/jpeg")

    def test_analyze_rejects_empty_image(self):
        with self.assertRaisesRegex(ValueError, "empty"):
            analyze(b"", "image/jpeg")

    def test_analyze_rejects_unsupported_media_type(self):
        with self.assertRaisesRegex(ValueError, "Unsupported"):
            analyze(b"data", "image/bmp")


if __name__ == "__main__":
    unittest.main()
