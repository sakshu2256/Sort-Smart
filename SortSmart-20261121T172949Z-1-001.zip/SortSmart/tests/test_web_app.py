import io
import json
import unittest
from unittest.mock import patch

import web_app


def example_result():
    return {
        "item": "Greasy takeaway box",
        "material": "Cardboard and plastic",
        "stream": "wet",
        "prep_steps": ["Separate the clean lid"],
        "reason": "Check local collection guidance.",
        "confidence": 0.8,
        "contamination": "Grease is visible.",
        "parts": [
            {
                "item": "Greasy cardboard box",
                "material": "Cardboard",
                "stream": "wet",
                "prep_steps": ["Keep the soiled section separate."],
            },
            {
                "item": "Clean lid",
                "material": "Plastic",
                "stream": "dry",
                "prep_steps": ["Rinse if accepted locally."],
            },
        ],
    }


class Response:
    def __init__(self, value):
        self.value = json.dumps(value).encode("utf-8")

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def read(self):
        return self.value


class SortSmartWebTests(unittest.TestCase):
    def setUp(self):
        self.client = web_app.app.test_client()

    def test_home_includes_multilingual_photo_and_text_inputs(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Describe the item", response.data)
        self.assertIn(b"Punjabi", response.data)
        self.assertIn(b"Read result aloud", response.data)
        self.assertIn(b"manifest.webmanifest", response.data)

    def test_service_worker_is_available_at_root_scope(self):
        response = self.client.get("/service-worker.js")
        try:
            self.assertEqual(response.status_code, 200)
            self.assertIn(b"sortsmart-shell-v4", response.data)
        finally:
            response.close()

    def test_text_analysis_returns_component_result(self):
        with patch("web_app.analyze_description", return_value=example_result()) as analyze:
            response = self.client.post(
                "/api/analyze",
                data={"description": "greasy box with plastic lid", "language": "Hindi"},
            )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.json["parts"]), 2)
        analyze.assert_called_once_with("greasy box with plastic lid", lang="Hindi")

    def test_rejects_missing_and_conflicting_inputs(self):
        missing = self.client.post("/api/analyze")
        conflicting = self.client.post(
            "/api/analyze",
            data={
                "description": "bottle",
                "image": (io.BytesIO(b"jpeg"), "item.jpg", "image/jpeg"),
            },
        )
        self.assertEqual(missing.status_code, 400)
        self.assertEqual(conflicting.status_code, 400)

    def test_rejects_unsupported_language(self):
        response = self.client.post(
            "/api/analyze",
            data={"description": "bottle", "language": "French"},
        )
        self.assertEqual(response.status_code, 400)

    def test_rejects_images_over_the_configured_limit(self):
        with patch("web_app.MAX_UPLOAD_BYTES", 4):
            response = self.client.post(
                "/api/analyze",
                data={"image": (io.BytesIO(b"12345"), "item.jpg", "image/jpeg")},
            )
        self.assertEqual(response.status_code, 413)

    def test_dropoff_search_sorts_nearest_first(self):
        overpass = {
            "elements": [
                {"type": "node", "lat": 12.02, "lon": 77.0, "tags": {"name": "Far"}},
                {"type": "node", "lat": 12.001, "lon": 77.0, "tags": {"name": "Near"}},
            ]
        }
        with patch("web_app.urllib.request.urlopen", return_value=Response(overpass)):
            response = self.client.get("/api/dropoffs?lat=12&lon=77")
        self.assertEqual(response.status_code, 200)
        self.assertEqual([place["name"] for place in response.json["places"]], ["Near", "Far"])

    def test_rejects_invalid_coordinates(self):
        response = self.client.get("/api/dropoffs?lat=91&lon=0")
        self.assertEqual(response.status_code, 400)

    def test_area_search_uses_openstreetmap_geocoder(self):
        with patch(
            "web_app.urllib.request.urlopen",
            return_value=Response([{"lat": "12.97", "lon": "77.59"}]),
        ):
            response = self.client.get("/api/geocode?q=Bengaluru")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["latitude"], 12.97)


if __name__ == "__main__":
    unittest.main()
